"use client"

import type React from "react"

import { useState } from "react"
import { Calendar, Clock, Package, Sparkles, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export function Booking() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: "",
    product: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    const message = `
*Novo Pedido - Sabor & Douceur*

*Nome:* ${formData.name}
*Email:* ${formData.email}
*Telefone:* ${formData.phone}
*Data do Evento:* ${formData.date}
*Horário:* ${formData.time}
*Produto:* ${formData.product}
*Observações:* ${formData.message || "Nenhuma"}
    `.trim()

    const whatsappUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`

    setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)
      window.open(whatsappUrl, "_blank")

      setTimeout(() => {
        setIsSuccess(false)
        setFormData({
          name: "",
          email: "",
          phone: "",
          date: "",
          time: "",
          product: "",
          message: "",
        })
      }, 3000)
    }, 1500)
  }

  return (
    <section
      id="agendamento"
      className="py-20 lg:py-32 relative overflow-hidden bg-gradient-to-b from-muted/20 to-background"
    >
      <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-secondary/25 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-primary/25 rounded-full blur-3xl animate-float [animation-delay:1s]" />
      <div className="absolute top-1/2 right-1/3 w-[400px] h-[400px] bg-accent/15 rounded-full blur-3xl animate-float [animation-delay:2.5s]" />

      <div className="absolute top-40 right-32 w-24 h-24 border-2 border-secondary/10 rounded-full animate-shape-float" />
      <div className="absolute bottom-40 left-32 w-20 h-20 border-2 border-primary/10 rotate-45 animate-shape-float [animation-delay:1.5s]" />

      <div className="container mx-auto px-4 lg:px-8 relative">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 space-y-6 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-full border border-primary/30 text-sm font-semibold text-foreground mb-4 hover:scale-105 transition-transform">
              <Sparkles size={16} className="animate-pulse text-primary" />
              Fácil e rápido
            </div>
            <h2 className="text-5xl md:text-7xl font-bold text-balance">Agende seu Pedido</h2>
            <p className="text-xl text-foreground/70 text-pretty leading-relaxed font-light">
              Preencha o formulário abaixo e entraremos em contato para confirmar seu pedido
            </p>
          </div>

          <Card className="border-border/50 shadow-2xl animate-fade-in-up [animation-delay:200ms] hover:shadow-primary/10 transition-all duration-500">
            <CardContent className="p-8 lg:p-10">
              {isSuccess ? (
                <div className="text-center py-12 space-y-6 animate-fade-in-up">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 text-green-600 animate-bounce">
                    <CheckCircle2 size={48} />
                  </div>
                  <h3 className="text-3xl font-bold text-foreground">Pedido enviado com sucesso!</h3>
                  <p className="text-lg text-foreground/70">
                    Entraremos em contato em breve para confirmar os detalhes.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2 group">
                      <Label
                        htmlFor="name"
                        className="group-focus-within:text-primary transition-colors text-base font-semibold"
                      >
                        Nome completo
                      </Label>
                      <Input
                        id="name"
                        placeholder="Seu nome"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 glass border-primary/30 text-base h-12"
                      />
                    </div>
                    <div className="space-y-2 group">
                      <Label
                        htmlFor="email"
                        className="group-focus-within:text-primary transition-colors text-base font-semibold"
                      >
                        E-mail
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="seu@email.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 glass border-primary/30 text-base h-12"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 group">
                    <Label
                      htmlFor="phone"
                      className="group-focus-within:text-primary transition-colors text-base font-semibold"
                    >
                      Telefone
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="(00) 00000-0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required
                      className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 glass border-primary/30 text-base h-12"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2 group">
                      <Label
                        htmlFor="date"
                        className="flex items-center gap-2 group-focus-within:text-primary transition-colors text-base font-semibold"
                      >
                        <Calendar size={18} />
                        Data do evento
                      </Label>
                      <Input
                        id="date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        required
                        className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 glass border-primary/30 text-base h-12"
                      />
                    </div>
                    <div className="space-y-2 group">
                      <Label
                        htmlFor="time"
                        className="flex items-center gap-2 group-focus-within:text-primary transition-colors text-base font-semibold"
                      >
                        <Clock size={18} />
                        Horário
                      </Label>
                      <Input
                        id="time"
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                        required
                        className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 glass border-primary/30 text-base h-12"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 group">
                    <Label
                      htmlFor="product"
                      className="flex items-center gap-2 group-focus-within:text-primary transition-colors text-base font-semibold"
                    >
                      <Package size={18} />
                      Produto desejado
                    </Label>
                    <Input
                      id="product"
                      placeholder="Ex: Bolo de aniversário para 30 pessoas"
                      value={formData.product}
                      onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                      required
                      className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 glass border-primary/30 text-base h-12"
                    />
                  </div>

                  <div className="space-y-2 group">
                    <Label
                      htmlFor="message"
                      className="group-focus-within:text-primary transition-colors text-base font-semibold"
                    >
                      Observações
                    </Label>
                    <Textarea
                      id="message"
                      placeholder="Detalhes adicionais sobre seu pedido..."
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="transition-all focus:scale-[1.01] focus:shadow-lg focus:shadow-primary/20 resize-none glass border-primary/30 text-base"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90 transition-all hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed group h-14 text-lg font-bold shadow-lg hover:shadow-xl"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="inline-block animate-spin mr-2">⏳</span>
                        Enviando...
                      </>
                    ) : (
                      <>
                        Enviar Pedido
                        <span className="ml-2 group-hover:translate-x-1 transition-transform inline-block">→</span>
                      </>
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <Card className="border-border/50 hover:border-primary/40 transition-all hover:-translate-y-1 duration-300">
              <CardContent className="p-6 text-center space-y-3">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary">
                  <Clock size={24} />
                </div>
                <h4 className="font-bold text-lg">Resposta Rápida</h4>
                <p className="text-sm text-foreground/70">Retornamos em até 24 horas</p>
              </CardContent>
            </Card>
            <Card className="border-border/50 hover:border-secondary/40 transition-all hover:-translate-y-1 duration-300">
              <CardContent className="p-6 text-center space-y-3">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-secondary/10 text-secondary">
                  <Package size={24} />
                </div>
                <h4 className="font-bold text-lg">Pedidos Personalizados</h4>
                <p className="text-sm text-foreground/70">Adaptamos ao seu gosto</p>
              </CardContent>
            </Card>
            <Card className="border-border/50 hover:border-primary/40 transition-all hover:-translate-y-1 duration-300">
              <CardContent className="p-6 text-center space-y-3">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary">
                  <Sparkles size={24} />
                </div>
                <h4 className="font-bold text-lg">Qualidade Garantida</h4>
                <p className="text-sm text-foreground/70">Ingredientes selecionados</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
