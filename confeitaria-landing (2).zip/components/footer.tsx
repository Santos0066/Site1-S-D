import { Instagram, Facebook, Mail, Phone, MapPin } from "lucide-react"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="relative overflow-hidden glass border-t border-primary/20">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background pointer-events-none" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-float [animation-delay:1.5s]" />

      <div
        className="absolute inset-0 opacity-[0.015] animate-pattern"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000000' fillOpacity='1' fillRule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: "40px 40px",
        }}
      />

      <div className="container mx-auto px-4 lg:px-8 py-16 lg:py-20 relative">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-16">
          <div className="space-y-6">
            <Image src="/images/logo-black.png" alt="Sabor & Douceur" width={180} height={60} className="h-12 w-auto" />
            <p className="text-foreground/70 leading-relaxed font-light">
              Criando momentos doces e salgados desde 2010
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-lg text-primary">Links Rápidos</h4>
            <nav className="flex flex-col space-y-3">
              <a
                href="#produtos"
                className="text-foreground/70 hover:text-primary transition-colors hover:translate-x-1 inline-block"
              >
                Produtos
              </a>
              <a
                href="#agendamento"
                className="text-foreground/70 hover:text-secondary transition-colors hover:translate-x-1 inline-block"
              >
                Agendamento
              </a>
              <a
                href="#depoimentos"
                className="text-foreground/70 hover:text-primary transition-colors hover:translate-x-1 inline-block"
              >
                Depoimentos
              </a>
              <a
                href="#equipe"
                className="text-foreground/70 hover:text-secondary transition-colors hover:translate-x-1 inline-block"
              >
                Equipe
              </a>
            </nav>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-lg text-secondary">Contato</h4>
            <div className="space-y-4">
              <a
                href="tel:+5511999999999"
                className="flex items-center gap-3 text-foreground/70 hover:text-primary transition-colors group"
              >
                <Phone size={20} className="group-hover:scale-110 transition-transform" />
                <span>(11) 99999-9999</span>
              </a>
              <a
                href="mailto:contato@sabordouceur.com.br"
                className="flex items-center gap-3 text-foreground/70 hover:text-secondary transition-colors group"
              >
                <Mail size={20} className="group-hover:scale-110 transition-transform" />
                <span>contato@sabordouceur.com.br</span>
              </a>
              <a
                href="https://maps.google.com/?q=Rua+das+Delícias+123+São+Paulo+SP"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-3 text-foreground/70 hover:text-primary transition-colors group"
              >
                <MapPin size={20} className="mt-1 flex-shrink-0 group-hover:scale-110 transition-transform" />
                <span>
                  Rua das Delícias, 123
                  <br />
                  São Paulo - SP
                </span>
              </a>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-lg bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Redes Sociais
            </h4>
            <div className="flex gap-4">
              <a
                href="https://instagram.com/sabordouceur"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/70 hover:text-secondary transition-all hover:scale-125 glow-pink p-2 glass rounded-full"
                aria-label="Instagram"
              >
                <Instagram size={24} />
              </a>
              <a
                href="https://facebook.com/sabordouceur"
                target="_blank"
                rel="noopener noreferrer"
                className="text-foreground/70 hover:text-primary transition-all hover:scale-125 glow-cyan p-2 glass rounded-full"
                aria-label="Facebook"
              >
                <Facebook size={24} />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-border/30 text-center text-sm text-foreground/50">
          <p>&copy; {new Date().getFullYear()} Sabor & Douceur. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
