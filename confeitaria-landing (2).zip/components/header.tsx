"use client"

import { useState, useEffect } from "react"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
      setIsMenuOpen(false)
    }
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? "bg-background/95 backdrop-blur-md shadow-lg border-b border-border"
          : "bg-background/80 backdrop-blur-sm border-b border-border/50"
      }`}
    >
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-20 lg:h-24">
          <div className="flex items-center gap-3 hover:scale-105 transition-transform cursor-pointer">
            <Image
              src="/images/logo-black.png"
              alt="Sabor & Douceur"
              width={200}
              height={80}
              className="h-14 lg:h-16 w-auto"
              priority
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection("#produtos")}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-all relative group"
            >
              Produtos
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
            </button>
            <button
              onClick={() => scrollToSection("#agendamento")}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-all relative group"
            >
              Agendamento
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-secondary to-primary group-hover:w-full transition-all duration-300" />
            </button>
            <button
              onClick={() => scrollToSection("#depoimentos")}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-all relative group"
            >
              Depoimentos
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
            </button>
            <button
              onClick={() => scrollToSection("#equipe")}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-all relative group"
            >
              Equipe
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-secondary to-primary group-hover:w-full transition-all duration-300" />
            </button>
            <Button
              size="sm"
              className="bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90 transition-all hover:scale-105 font-semibold shadow-md"
            >
              Fazer Pedido
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-foreground hover:scale-110 transition-transform hover:text-primary"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <nav className="md:hidden py-6 space-y-4 border-t border-border animate-fade-in-up bg-background">
            <button
              onClick={() => scrollToSection("#produtos")}
              className="block w-full text-left text-sm font-medium text-foreground/70 hover:text-primary transition-all py-3 hover:translate-x-2 hover:pl-2"
            >
              Produtos
            </button>
            <button
              onClick={() => scrollToSection("#agendamento")}
              className="block w-full text-left text-sm font-medium text-foreground/70 hover:text-secondary transition-all py-3 hover:translate-x-2 hover:pl-2"
            >
              Agendamento
            </button>
            <button
              onClick={() => scrollToSection("#depoimentos")}
              className="block w-full text-left text-sm font-medium text-foreground/70 hover:text-primary transition-all py-3 hover:translate-x-2 hover:pl-2"
            >
              Depoimentos
            </button>
            <button
              onClick={() => scrollToSection("#equipe")}
              className="block w-full text-left text-sm font-medium text-foreground/70 hover:text-secondary transition-all py-3 hover:translate-x-2 hover:pl-2"
            >
              Equipe
            </button>
            <Button
              size="sm"
              className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90 glow-cyan font-semibold"
            >
              Fazer Pedido
            </Button>
          </nav>
        )}
      </div>
    </header>
  )
}
