"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ChevronDown, Sparkles } from "lucide-react"
import Image from "next/image"

export function Hero() {
  const heroRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (!heroRef.current) return
      const scrolled = window.scrollY
      const parallax = scrolled * 0.3
      heroRef.current.style.transform = `translateY(${parallax}px)`
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.querySelector(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 lg:pt-24 bg-gradient-to-b from-background via-muted/10 to-background">
      <div ref={heroRef} className="absolute inset-0 z-0 transition-transform duration-100">
        <img
          src="/luxury-confectionery-dark-elegant.jpg"
          alt="Confeitaria"
          className="w-full h-full object-cover opacity-5"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/98 to-background" />
        <div
          className="absolute inset-0 opacity-[0.02] animate-pattern"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23000000' fillOpacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: "60px 60px",
          }}
        />
      </div>

      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-3xl animate-float [animation-delay:1s]" />
      <div className="absolute top-1/3 right-1/3 w-64 h-64 bg-accent/3 rounded-full blur-3xl animate-float [animation-delay:2s]" />

      <div className="absolute top-32 right-20 w-24 h-24 border-2 border-primary/10 rounded-full animate-shape-float" />
      <div className="absolute bottom-32 left-20 w-20 h-20 border-2 border-secondary/10 rotate-45 animate-shape-float [animation-delay:1.5s]" />
      <div className="absolute top-1/2 left-1/4 w-16 h-16 border-2 border-accent/10 rounded-lg animate-shape-float [animation-delay:3s]" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="max-w-5xl mx-auto text-center space-y-10 animate-fade-in-up">
          <div className="flex justify-center mb-8 animate-fade-in-up [animation-delay:100ms]">
            <Image
              src="/images/logo-black.png"
              alt="Sabor & Douceur"
              width={350}
              height={120}
              className="h-24 lg:h-32 w-auto hover:scale-105 transition-transform duration-500"
              priority
            />
          </div>

          <div className="space-y-6 animate-fade-in-up [animation-delay:200ms]">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-balance leading-[1.1] tracking-tight text-foreground">
              Sabores que encantam,
              <br />
              momentos que ficam
            </h1>
          </div>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto text-pretty leading-relaxed animate-fade-in-up [animation-delay:400ms]">
            Criamos doces e salgados artesanais com ingredientes selecionados para tornar suas celebrações ainda mais
            especiais
          </p>

          <div className="flex flex-wrap items-center justify-center gap-8 text-sm text-muted-foreground animate-fade-in-up [animation-delay:500ms]">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-primary" />
              <span>Ingredientes Premium</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-secondary" />
              <span>Feito com Amor</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-primary" />
              <span>Entrega Pontual</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-6 animate-fade-in-up [animation-delay:600ms]">
            <Button
              size="lg"
              onClick={() => scrollToSection("#produtos")}
              className="bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90 px-10 py-7 text-lg group transition-all hover:scale-105 font-semibold shadow-lg hover:shadow-xl"
            >
              Ver Cardápio
              <span className="ml-2 group-hover:translate-x-1 transition-transform inline-block">→</span>
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollToSection("#agendamento")}
              className="px-10 py-7 text-lg hover:bg-muted transition-all hover:scale-105 border-border text-foreground font-semibold bg-transparent hover:border-primary"
            >
              Agendar Pedido
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <ChevronDown className="text-muted-foreground" size={40} />
      </div>
    </section>
  )
}
