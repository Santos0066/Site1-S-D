"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Cake, UtensilsCrossed, Sparkles } from "lucide-react"

const products = [
  {
    category: "Doces",
    icon: Cake,
    items: [
      {
        name: "Brigadeiros Gourmet",
        description: "Brigadeiros artesanais com diversos sabores e coberturas premium",
        image: "/gourmet-brigadeiros-chocolate-truffles.jpg",
        badge: "Mais vendido",
      },
      {
        name: "Bolos Personalizados",
        description: "Bolos sob medida para aniversários, casamentos e eventos especiais",
        image: "/elegant-custom-decorated-cake.jpg",
        badge: "Exclusivo",
      },
      {
        name: "Tortas e Pavês",
        description: "Sobremesas cremosas e irresistíveis para toda ocasião",
        image: "/delicious-layered-dessert-pav-.jpg",
      },
    ],
  },
  {
    category: "Salgados",
    icon: UtensilsCrossed,
    items: [
      {
        name: "Salgados Fritos",
        description: "Coxinhas, risoles, bolinhas de queijo e muito mais",
        image: "/brazilian-fried-savory-snacks-coxinha.jpg",
        badge: "Tradicional",
      },
      {
        name: "Salgados Assados",
        description: "Opções mais leves e saudáveis sem perder o sabor",
        image: "/baked-savory-pastries-empanadas.jpg",
      },
      {
        name: "Mini Sanduíches",
        description: "Perfeitos para eventos e festas corporativas",
        image: "/elegant-mini-sandwiches-catering.jpg",
      },
    ],
  },
]

export function Products() {
  const [visibleItems, setVisibleItems] = useState<Set<number>>(new Set())
  const itemRefs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const observers = itemRefs.current.map((ref, index) => {
      if (!ref) return null

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setVisibleItems((prev) => new Set(prev).add(index))
            }
          })
        },
        { threshold: 0.1 },
      )

      observer.observe(ref)
      return observer
    })

    return () => {
      observers.forEach((observer) => observer?.disconnect())
    }
  }, [])

  const handleProductInquiry = (productName: string) => {
    const message = encodeURIComponent(`Olá! Gostaria de saber mais sobre: ${productName}`)
    window.open(`https://wa.me/5511999999999?text=${message}`, "_blank")
  }

  let itemIndex = 0

  return (
    <section
      id="produtos"
      className="py-20 lg:py-32 bg-gradient-to-b from-background to-muted/20 relative overflow-hidden"
    >
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] bg-secondary/5 rounded-full blur-3xl animate-float [animation-delay:1.5s]" />
      <div className="absolute top-1/2 left-1/2 w-[400px] h-[400px] bg-accent/3 rounded-full blur-3xl animate-float [animation-delay:3s]" />

      <div className="absolute top-20 left-10 w-20 h-20 border-2 border-primary/10 rounded-full animate-shape-float" />
      <div className="absolute bottom-40 right-20 w-16 h-16 border-2 border-secondary/10 rotate-45 animate-shape-float [animation-delay:2s]" />
      <div className="absolute top-1/3 right-1/3 w-12 h-12 border-2 border-accent/10 rounded-full animate-shape-float [animation-delay:4s]" />

      <div className="container mx-auto px-4 lg:px-8 relative">
        <div className="text-center mb-20 space-y-6 animate-fade-in-up">
          <h2 className="text-5xl md:text-7xl font-bold text-balance text-foreground">Nossos Produtos</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
            Cada produto é feito com carinho e ingredientes de primeira qualidade
          </p>
        </div>

        <div className="space-y-24">
          {products.map((category) => (
            <div key={category.category}>
              <div className="flex items-center justify-center gap-4 mb-12 group">
                <div className="h-px w-16 bg-gradient-to-r from-transparent via-border to-border group-hover:via-primary transition-colors duration-500" />
                <div className="relative">
                  <category.icon
                    className="text-primary group-hover:scale-110 transition-transform duration-300"
                    size={36}
                  />
                  <Sparkles className="absolute -top-1 -right-1 text-secondary animate-pulse" size={14} />
                </div>
                <h3 className="text-4xl md:text-5xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
                  {category.category}
                </h3>
                <div className="relative">
                  <category.icon
                    className="text-secondary group-hover:scale-110 transition-transform duration-300"
                    size={36}
                  />
                  <Sparkles
                    className="absolute -top-1 -left-1 text-primary animate-pulse [animation-delay:500ms]"
                    size={14}
                  />
                </div>
                <div className="h-px w-16 bg-gradient-to-l from-transparent via-border to-border group-hover:via-secondary transition-colors duration-500" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {category.items.map((item) => {
                  const currentIndex = itemIndex++
                  const isVisible = visibleItems.has(currentIndex)

                  return (
                    <div
                      key={item.name}
                      ref={(el) => {
                        itemRefs.current[currentIndex] = el
                      }}
                      className={`transition-all duration-700 ${
                        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                      }`}
                      style={{ transitionDelay: `${(currentIndex % 3) * 100}ms` }}
                    >
                      <Card className="overflow-hidden group hover:shadow-xl transition-all duration-500 hover:-translate-y-2 bg-card border-border hover:border-primary/40">
                        <div className="aspect-square overflow-hidden relative">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent opacity-40 group-hover:opacity-60 transition-opacity duration-500" />
                          {item.badge && (
                            <Badge className="absolute top-4 right-4 bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-lg animate-fade-in-up border-0 font-semibold">
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                        <CardContent className="p-6 space-y-4">
                          <h4 className="text-2xl font-bold group-hover:text-primary transition-colors">{item.name}</h4>
                          <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                          <Button
                            onClick={() => handleProductInquiry(item.name)}
                            className="w-full bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90 transition-all group/btn"
                          >
                            Pedir agora
                            <span className="ml-2 group-hover/btn:translate-x-1 transition-transform inline-block">
                              →
                            </span>
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
