"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award } from "lucide-react"

const team = [
  {
    name: "Carla Mendes",
    role: "Chef Confeiteira",
    description: "Especialista em bolos decorados com mais de 15 anos de experiência",
    image: "/professional-female-pastry-chef-portrait.jpg",
    specialty: "Bolos",
  },
  {
    name: "Roberto Lima",
    role: "Mestre Salgadeiro",
    description: "Criador dos nossos salgados artesanais e receitas exclusivas",
    image: "/professional-male-chef.png",
    specialty: "Salgados",
  },
  {
    name: "Juliana Costa",
    role: "Chocolatier",
    description: "Especializada em chocolates finos e brigadeiros gourmet",
    image: "/professional-female-chocolatier-portrait.jpg",
    specialty: "Chocolates",
  },
]

export function Team() {
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const cardRefs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const observers = cardRefs.current.map((ref, index) => {
      if (!ref) return null

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setVisibleCards((prev) => new Set(prev).add(index))
            }
          })
        },
        { threshold: 0.1 },
      )

      observer.observe(ref)
      return observer
    })

    return () => {
      observers.forEach((observer) => observer?.disconnect())
    }
  }, [])

  return (
    <section
      id="equipe"
      className="py-20 lg:py-32 relative overflow-hidden bg-gradient-to-b from-muted/20 to-background"
    >
      <div className="absolute top-1/3 right-1/4 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/3 left-1/4 w-[600px] h-[600px] bg-secondary/10 rounded-full blur-3xl animate-float [animation-delay:1s]" />
      <div className="absolute top-1/2 right-1/2 w-[400px] h-[400px] bg-accent/8 rounded-full blur-3xl animate-float [animation-delay:2.5s]" />

      <div className="absolute top-40 left-40 w-24 h-24 border-2 border-primary/10 rotate-45 animate-shape-float" />
      <div className="absolute bottom-40 right-40 w-20 h-20 border-2 border-secondary/10 rounded-full animate-shape-float [animation-delay:1.5s]" />

      <div className="container mx-auto px-4 lg:px-8 relative">
        <div className="text-center mb-20 space-y-6 animate-fade-in-up">
          <h2 className="text-5xl md:text-7xl font-bold text-balance text-foreground">Nossa Equipe</h2>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto text-pretty leading-relaxed font-light">
            Profissionais apaixonados por criar experiências gastronômicas inesquecíveis
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {team.map((member, index) => {
            const isVisible = visibleCards.has(index)

            return (
              <div
                key={member.name}
                ref={(el) => {
                  cardRefs.current[index] = el
                }}
                className={`transition-all duration-700 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <Card className="overflow-hidden group hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border-border hover:border-primary/40">
                  <div className="aspect-square overflow-hidden relative">
                    <img
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent opacity-70 group-hover:opacity-90 transition-opacity duration-500" />
                    <Badge className="absolute top-4 right-4 bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-lg backdrop-blur-sm border-0 font-semibold flex items-center gap-1.5">
                      <Award size={14} />
                      {member.specialty}
                    </Badge>
                  </div>
                  <CardContent className="p-8 space-y-3 text-center">
                    <h3 className="text-2xl font-bold group-hover:text-primary transition-colors">{member.name}</h3>
                    <p className="text-secondary font-semibold text-lg">{member.role}</p>
                    <p className="text-foreground/70 leading-relaxed">{member.description}</p>
                  </CardContent>
                </Card>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
