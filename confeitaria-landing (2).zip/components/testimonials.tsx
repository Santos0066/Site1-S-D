"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Quote } from "lucide-react"
import Image from "next/image"

const testimonials = [
  {
    name: "Maria Silva",
    role: "Cliente",
    content:
      "Os doces são simplesmente perfeitos! Encomendei para o aniversário da minha filha e todos os convidados elogiaram. Qualidade excepcional!",
    rating: 5,
    image: "/smiling-brown-haired-woman.png",
  },
  {
    name: "João Santos",
    role: "Cliente",
    content:
      "Melhor confeitaria da região! Os salgados são deliciosos e sempre fresquinhos. Atendimento impecável e entrega pontual.",
    rating: 5,
    image: "/smiling-man-short-hair.png",
  },
  {
    name: "Ana Paula",
    role: "Cliente",
    content:
      "Fiz o bolo de casamento com eles e foi um sucesso! Lindo, saboroso e exatamente como eu imaginei. Super recomendo!",
    rating: 5,
    image: "/smiling-woman-long-hair.png",
  },
]

export function Testimonials() {
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const cardRefs = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const observers = cardRefs.current.map((ref, index) => {
      if (!ref) return null

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setVisibleCards((prev) => new Set(prev).add(index))
            }
          })
        },
        { threshold: 0.1 },
      )

      observer.observe(ref)
      return observer
    })

    return () => {
      observers.forEach((observer) => observer?.disconnect())
    }
  }, [])

  return (
    <section
      id="depoimentos"
      className="py-20 lg:py-32 relative overflow-hidden bg-gradient-to-b from-background to-muted/20"
    >
      <div className="absolute top-1/3 left-1/3 w-[500px] h-[500px] bg-accent/20 rounded-full blur-3xl animate-float [animation-delay:1s]" />
      <div className="absolute bottom-1/3 right-1/3 w-[500px] h-[500px] bg-primary/15 rounded-full blur-3xl animate-float [animation-delay:2s]" />
      <div className="absolute top-1/2 left-1/2 w-[350px] h-[350px] bg-secondary/10 rounded-full blur-3xl animate-float [animation-delay:3s]" />

      <div className="absolute top-32 left-20 w-20 h-20 border-2 border-accent/10 rounded-lg animate-shape-float" />
      <div className="absolute bottom-32 right-32 w-16 h-16 border-2 border-primary/10 rounded-full animate-shape-float [animation-delay:2s]" />

      <div className="container mx-auto px-4 lg:px-8 relative">
        <div className="text-center mb-20 space-y-6 animate-fade-in-up">
          <h2 className="text-5xl md:text-7xl font-bold text-balance">O que dizem nossos clientes</h2>
          <p className="text-xl text-foreground/70 max-w-2xl mx-auto text-pretty leading-relaxed font-light">
            A satisfação de quem prova nossos produtos é nossa maior recompensa
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => {
            const isVisible = visibleCards.has(index)

            return (
              <div
                key={testimonial.name}
                ref={(el) => {
                  cardRefs.current[index] = el
                }}
                className={`transition-all duration-700 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <Card className="hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border-border/50 hover:border-primary/40 group relative overflow-hidden h-full">
                  <div className="absolute top-6 right-6 text-muted/10 group-hover:text-muted/20 transition-colors group-hover:scale-110 duration-500">
                    <Quote size={64} />
                  </div>
                  <CardContent className="p-8 space-y-5 relative">
                    <div className="flex gap-1">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <Star
                          key={i}
                          size={20}
                          className="fill-amber-400 text-amber-400 group-hover:scale-125 transition-transform"
                          style={{ transitionDelay: `${i * 50}ms` }}
                        />
                      ))}
                    </div>
                    <p className="text-foreground/80 leading-relaxed relative z-10 text-lg">{testimonial.content}</p>
                    <div className="pt-4 border-t border-border/50 flex items-center gap-4">
                      <div className="relative w-14 h-14 rounded-full overflow-hidden ring-2 ring-primary/20 group-hover:ring-primary/40 transition-all flex-shrink-0">
                        <Image
                          src={testimonial.image || "/placeholder.svg"}
                          alt={testimonial.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <p className="font-bold text-lg group-hover:text-primary transition-colors">
                          {testimonial.name}
                        </p>
                        <p className="text-sm text-foreground/60 font-medium">{testimonial.role}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
